# survilBot-project
for Robotics lab project
Reference links

For Turtlebot control:
https://www.clearpathrobotics.com/assets/guides/kinetic/turtlebot/index.html#
http://wiki.ros.org/turtlebot/Tutorials/indigo

For Telegram control:
https://maker.pro/raspberry-pi/projects/how-to-create-a-telegram-bot-with-a-raspberry-pi 

For Camera part:
https://learn.turtlebot.com/2015/02/04/3/
https://docs.opencv.org/4.5.0/db/deb/tutorial_display_image.html
